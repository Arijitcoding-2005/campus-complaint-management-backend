package com.campus.complaintmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusComplaintManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusComplaintManagementSystemApplication.class, args);
	}

}
